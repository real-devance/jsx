import React from "react";

export default function Brand() {
  return (
    <a className="brand" href="/" aria-label="Accessly home">
      <span className="brand-mark" aria-hidden="true">
        <span />
      </span>
      <span>accessly</span>
    </a>
  );
}
