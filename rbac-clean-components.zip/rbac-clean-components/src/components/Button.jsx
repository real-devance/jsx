import React from "react";

export default function Button({
  children,
  variant = "primary",
  type = "button",
  onClick,
  className = "",
}) {
  return (
    <button
      className={`button button--${variant} ${className}`.trim()}
      type={type}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
