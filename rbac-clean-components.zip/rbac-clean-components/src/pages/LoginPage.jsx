import React, { useState } from "react";
import Brand from "../components/Brand";
import Button from "../components/Button";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    // Visual prototype only. Connect your authentication flow here.
  }

  return (
    <main className="login-shell">
      <header className="login-nav">
        <Brand />
        <a className="login-back" href="/">← Back to home</a>
      </header>

      <section className="login-layout">
        <div className="login-intro">
          <p className="eyebrow"><span className="eyebrow-line" /> YOUR WORKSPACE, AWAITS</p>
          <h1>Good to have<br />you <span>back.</span></h1>
          <p>Sign in to manage your workspace, people, and permissions.</p>
          <div className="login-side-note">
            <span className="side-note-mark">“</span>
            <p>Security should feel simple.<br /><strong>That’s the whole idea.</strong></p>
          </div>
        </div>

        <div className="login-card">
          <div className="login-card-heading">
            <div className="login-icon" aria-hidden="true"><span className="brand-mark"><span /></span></div>
            <p className="eyebrow">WELCOME BACK</p>
            <h2>Sign in to Accessly</h2>
            <p>Enter your details to continue.</p>
          </div>

          <form className="login-form" onSubmit={handleSubmit}>
            <label htmlFor="email">Work email</label>
            <input id="email" name="email" type="email" autoComplete="email" placeholder="you@company.com" required />

            <div className="password-label">
              <label htmlFor="password">Password</label>
              <a href="#forgot-password" onClick={(event) => event.preventDefault()}>Forgot password?</a>
            </div>
            <div className="password-wrap">
              <input id="password" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Enter your password" required />
              <button className="password-toggle" type="button" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? "Hide password" : "Show password"}>
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>

            <Button type="submit" className="login-submit">Sign in <span aria-hidden="true">→</span></Button>
          </form>

          <div className="login-divider"><span /> <p>New to Accessly?</p> <span /></div>
          <a className="button button--secondary create-account" href="#create-account" onClick={(event) => event.preventDefault()}>Create an account <span aria-hidden="true">↗</span></a>
          <p className="login-terms">By continuing, you agree to our <a href="#terms">Terms</a> and <a href="#privacy">Privacy Policy</a>.</p>
        </div>
      </section>

      <footer className="login-footer">
        <span>© {new Date().getFullYear()} Accessly</span>
        <span>Secure access. Thoughtfully designed.</span>
      </footer>
    </main>
  );
}
