import React from "react";
import Brand from "../components/Brand";
import Button from "../components/Button";

const features = [
  {
    number: "01",
    title: "Roles that make sense",
    description: "Create clear roles for admins, managers, and team members.",
  },
  {
    number: "02",
    title: "Permissions, precisely",
    description: "Give every person access to only what they need.",
  },
  {
    number: "03",
    title: "A clear audit trail",
    description: "Understand who changed what, and when.",
  },
];

const people = [
  { initials: "AS", name: "Aarav Sharma", email: "aarav@company.com", role: "Administrator", tone: "violet" },
  { initials: "PV", name: "Priya Verma", email: "priya@company.com", role: "Manager", tone: "blue" },
  { initials: "RM", name: "Rohit Mehta", email: "rohit@company.com", role: "Editor", tone: "green" },
];

function DashboardPreview() {
  return (
    <div className="preview" aria-label="Illustrative user access dashboard">
      <div className="preview-topbar">
        <div className="preview-breadcrumb"><span className="preview-dot" /> Workspace <span className="slash">/</span> People</div>
        <span className="preview-avatar">A</span>
      </div>
      <div className="preview-content">
        <div className="preview-heading">
          <div>
            <p className="eyebrow">WORKSPACE</p>
            <h2>People & access</h2>
            <p className="muted">Manage the people in your workspace.</p>
          </div>
          <button className="mini-button" type="button">＋ Invite</button>
        </div>
        <div className="preview-table-head">
          <span>PERSON</span><span>ROLE</span><span>STATUS</span>
        </div>
        {people.map((person) => (
          <div className="person-row" key={person.email}>
            <div className="person-cell">
              <span className={`person-avatar person-avatar--${person.tone}`}>{person.initials}</span>
              <span><strong>{person.name}</strong><small>{person.email}</small></span>
            </div>
            <span className="role-cell">{person.role}</span>
            <span className="status"><i /> Active</span>
          </div>
        ))}
        <div className="preview-footer"><span>3 people</span><span>Updated just now</span></div>
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <main className="site-shell">
      <header className="nav">
        <Brand />
        <nav className="nav-links" aria-label="Main navigation">
          <a href="#product">Product</a>
          <a href="#features">Features</a>
          <a href="#security">Security</a>
        </nav>
        <div className="nav-actions">
          <a className="nav-signin" href="/login">Sign in</a>
          <a className="button button--primary nav-cta" href="/login">Get started <span aria-hidden="true">↗</span></a>
        </div>
      </header>

      <section className="hero" id="product">
        <div className="hero-copy">
          <p className="eyebrow"><span className="eyebrow-line" /> ACCESS CONTROL, MADE CLEAR</p>
          <h1>Access for the right people.<br /><span>Nothing more.</span></h1>
          <p className="hero-description">
            A calmer way to manage users, roles, and permissions across your application.
          </p>
          <div className="hero-actions">
            <a className="button button--primary" href="/login">Get started <span aria-hidden="true">↗</span></a>
            <a className="button button--secondary" href="#features">Explore features <span aria-hidden="true">↓</span></a>
          </div>
          <div className="hero-note"><span className="note-check">✓</span> Simple to set up. Clear by design.</div>
        </div>
        <div className="hero-visual">
          <div className="visual-caption"><span className="caption-dot" /> YOUR WORKSPACE <span className="caption-divider">/</span> ACCESS OVERVIEW</div>
          <DashboardPreview />
          <div className="floating-note"><span className="floating-check">✓</span><span><strong>Permissions updated</strong><small>Changes saved successfully</small></span></div>
        </div>
      </section>

      <section className="trust-strip" aria-label="Product principles">
        <span>BUILT FOR CLARITY</span>
        <span className="trust-divider" />
        <span>SECURE BY DEFAULT</span>
        <span className="trust-divider" />
        <span>READY TO SCALE</span>
      </section>

      <section className="features-section" id="features">
        <div className="section-heading">
          <p className="eyebrow">LESS COMPLEXITY. MORE CONTROL.</p>
          <h2>Everything in its right place.</h2>
          <p>Useful controls, without the clutter.</p>
        </div>
        <div className="feature-grid">
          {features.map((feature) => (
            <article className="feature" key={feature.number}>
              <span className="feature-number">{feature.number}</span>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
              <span className="feature-arrow" aria-hidden="true">↗</span>
            </article>
          ))}
        </div>
      </section>

      <footer className="site-footer" id="security">
        <Brand />
        <span>Thoughtful access control for modern teams.</span>
        <a href="/login">Sign in <span aria-hidden="true">↗</span></a>
      </footer>
    </main>
  );
}
