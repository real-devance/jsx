# Clean RBAC UI starter

A minimal React UI concept for review: separate Home and Login page components, no images, no backend/auth wiring.

## Files
- `src/pages/HomePage.jsx` — landing page
- `src/pages/LoginPage.jsx` — login page
- `src/components/Brand.jsx` — shared wordmark
- `src/components/Button.jsx` — shared button
- `src/styles.css` — shared styling

## Use
Copy these files into your React/Vite project, import `src/styles.css` once in your app entry, then render `HomePage` or `LoginPage` from your router.

The form is visual-only for approval; connect it to your auth provider after the UI is approved.
