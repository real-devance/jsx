import DeLinkAccounts from "./pages/DeLinkAccounts";

export default function App() {
  return <DeLinkAccounts />;
}