# Accessly — Clean RBAC UI

Minimal, responsive landing and login pages built with **React + TypeScript + Vite + Tailwind CSS**, using shadcn/ui-style components. No photos or decorative images.

## Run locally

```bash
npm install
npm run dev
```

## Pages and components

- `/` — landing page and illustrative access dashboard
- `/login` — login UI with password visibility toggle
- `src/pages/HomePage.tsx` — home page
- `src/pages/LoginPage.tsx` — login page
- `src/components/Brand.tsx` — shared wordmark
- `src/components/ui/button.tsx` — reusable shadcn-style button
- `src/components/ui/input.tsx` — reusable shadcn-style input
- `src/components/ui/label.tsx` — reusable label
- `src/index.css` — Tailwind layers and design tokens

## shadcn/ui

The project includes `components.json`, Tailwind CSS variables, and the shadcn-style `cn()` helper. To add more components later, run the shadcn CLI in this project, for example:

```bash
npx shadcn@latest add card separator
```

## Note

This is a **front-end design prototype**. The login form does not authenticate yet. Connect your chosen auth provider and add actual role checks / protected routes before production use.
