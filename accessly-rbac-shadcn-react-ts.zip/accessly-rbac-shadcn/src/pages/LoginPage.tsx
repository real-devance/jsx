import { useState, type FormEvent } from "react";
import { ArrowLeft, ArrowRight, Eye, EyeOff, LockKeyhole, Mail } from "lucide-react";
import { Link } from "react-router-dom";
import Brand from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    // UI prototype only: connect your authentication provider here.
  }

  return (
    <main className="mx-auto flex min-h-screen w-[min(1240px,calc(100%-32px))] flex-col sm:w-[min(1240px,calc(100%-64px))]">
      <header className="flex min-h-[78px] items-center justify-between border-b border-gray-100">
        <Brand />
        <Link to="/" className="inline-flex items-center gap-2 text-xs text-muted-foreground transition-colors hover:text-foreground"><ArrowLeft className="h-3.5 w-3.5" /> Back to home</Link>
      </header>

      <section className="grid flex-1 items-center gap-12 py-12 sm:py-16 lg:grid-cols-[1fr_440px] lg:gap-[10%] lg:px-[8%]">
        <div className="hidden lg:block">
          <p className="eyebrow"><span className="eyebrow-line" /> YOUR WORKSPACE, AWAITS</p>
          <h1 className="text-[64px] font-semibold leading-[1.04] tracking-[-.065em]">Good to have<br />you <span className="text-gray-400">back.</span></h1>
          <p className="mt-6 max-w-[350px] text-[15px] leading-7 text-muted-foreground">Sign in to manage your workspace, people, and permissions.</p>
          <div className="mt-16 flex items-start gap-3">
            <span className="font-serif text-5xl leading-none text-indigo-200">“</span>
            <p className="text-xs leading-6 text-muted-foreground">Security should feel simple.<br /><strong className="font-semibold text-foreground">That’s the whole idea.</strong></p>
          </div>
        </div>

        <div className="mx-auto w-full max-w-[440px] rounded-2xl border bg-white p-6 shadow-subtle sm:p-8">
          <div className="mb-7">
            <div className="mb-7 grid h-11 w-11 place-items-center rounded-xl border"><span className="brand-mark"><span /></span></div>
            <p className="eyebrow mb-2">WELCOME BACK</p>
            <h2 className="text-[26px] font-semibold tracking-[-.045em]">Sign in to Accessly</h2>
            <p className="mt-2 text-xs text-muted-foreground">Enter your details to continue.</p>
          </div>

          <form className="space-y-4" onSubmit={handleSubmit}>
            <div className="space-y-2">
              <Label htmlFor="email">Work email</Label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input id="email" name="email" type="email" autoComplete="email" placeholder="you@company.com" className="pl-10" required />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-3">
                <Label htmlFor="password">Password</Label>
                <a href="#forgot-password" onClick={(event) => event.preventDefault()} className="text-[10px] text-muted-foreground hover:text-foreground">Forgot password?</a>
              </div>
              <div className="relative">
                <LockKeyhole className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input id="password" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Enter your password" className="pl-10 pr-12" required />
                <button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Hide password" : "Show password"} className="absolute right-3 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground">
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="mt-2 w-full rounded-lg">Sign in <ArrowRight className="ml-1 h-4 w-4" /></Button>
          </form>

          <div className="my-6 flex items-center gap-3">
            <span className="h-px flex-1 bg-border" /><span className="text-[10px] text-muted-foreground">New to Accessly?</span><span className="h-px flex-1 bg-border" />
          </div>
          <Button asChild variant="outline" className="w-full rounded-lg"><a href="#create-account" onClick={(event) => event.preventDefault()}>Create an account <ArrowRight className="ml-1 h-4 w-4" /></a></Button>
          <p className="mt-5 text-center text-[10px] leading-5 text-muted-foreground">By continuing, you agree to our <a href="#terms" className="underline underline-offset-2 hover:text-foreground">Terms</a> and <a href="#privacy" className="underline underline-offset-2 hover:text-foreground">Privacy Policy</a>.</p>
        </div>
      </section>

      <footer className="flex flex-wrap justify-between gap-3 border-t py-5 text-[10px] text-muted-foreground">
        <span>© {new Date().getFullYear()} Accessly</span><span>Secure access. Thoughtfully designed.</span>
      </footer>
    </main>
  );
}