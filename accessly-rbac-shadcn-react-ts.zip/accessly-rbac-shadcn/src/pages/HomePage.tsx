import { ArrowDown, ArrowUpRight, Check, Shield, Users, BarChart3 } from "lucide-react";
import { Link } from "react-router-dom";
import Brand from "@/components/Brand";
import { Button } from "@/components/ui/button";

const people = [
  { initials: "AS", name: "Aarav Sharma", email: "aarav@company.com", role: "Administrator", tone: "violet" },
  { initials: "PV", name: "Priya Verma", email: "priya@company.com", role: "Manager", tone: "blue" },
  { initials: "RM", name: "Rohit Mehta", email: "rohit@company.com", role: "Editor", tone: "green" },
];

const features = [
  { number: "01", title: "Role-based access", description: "Define roles and control permissions at every level.", icon: Users },
  { number: "02", title: "Security first", description: "Built with best practices to help keep your data safe.", icon: Shield },
  { number: "03", title: "Built for teams", description: "From startups to enterprises, Accessly grows with you.", icon: BarChart3 },
];

function DashboardPreview() {
  return (
    <div className="overflow-hidden rounded-2xl border bg-white shadow-subtle">
      <div className="flex h-14 items-center justify-between border-b px-5">
        <p className="text-xs font-semibold text-muted-foreground"><span className="mr-2 inline-block h-2 w-2 rounded-sm bg-indigo-500" />Workspace <span className="mx-2 text-gray-300">/</span> People</p>
        <span className="grid h-7 w-7 place-items-center rounded-full bg-[#f0edff] text-xs font-bold text-[#5a56ba]">A</span>
      </div>
      <div className="p-5 sm:p-6">
        <div className="mb-6 flex items-center justify-between gap-3">
          <div>
            <p className="mb-2 text-[9px] font-bold tracking-[1.5px] text-muted-foreground">WORKSPACE</p>
            <h2 className="text-xl font-semibold tracking-tight">People & access</h2>
            <p className="mt-1 text-[11px] text-muted-foreground">Manage the people in your workspace.</p>
          </div>
          <Button size="sm" variant="outline" className="rounded-lg">＋ Invite</Button>
        </div>
        <div className="grid grid-cols-[1.7fr_1fr_.65fr] gap-2 pb-3 text-[8px] font-semibold tracking-[1px] text-muted-foreground">
          <span>PERSON</span><span>ROLE</span><span>STATUS</span>
        </div>
        {people.map((person) => (
          <div key={person.email} className="grid min-h-[64px] grid-cols-[1.7fr_1fr_.65fr] items-center gap-2 border-t text-[10px]">
            <div className="flex min-w-0 items-center gap-2">
              <span className={`person-avatar person-avatar--${person.tone}`}>{person.initials}</span>
              <span className="min-w-0">
                <strong className="block truncate text-[10px] font-semibold">{person.name}</strong>
                <small className="mt-1 block truncate text-[9px] text-muted-foreground">{person.email}</small>
              </span>
            </div>
            <span className="text-muted-foreground">{person.role}</span>
            <span className="inline-flex items-center gap-1.5 text-[9px] text-muted-foreground"><i className="h-1.5 w-1.5 rounded-full bg-emerald-500" />Active</span>
          </div>
        ))}
        <div className="flex justify-between border-t pt-4 text-[9px] text-muted-foreground"><span>3 people</span><span>Updated just now</span></div>
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <main className="mx-auto w-[min(1240px,calc(100%-32px))] sm:w-[min(1240px,calc(100%-64px))]">
      <header className="flex min-h-[78px] items-center justify-between gap-5 border-b border-gray-100">
        <Brand />
        <nav className="hidden items-center gap-7 text-xs text-muted-foreground md:flex" aria-label="Main navigation">
          <a href="#product" className="transition-colors hover:text-foreground">Product</a>
          <a href="#features" className="transition-colors hover:text-foreground">Features</a>
          <a href="#security" className="transition-colors hover:text-foreground">Security</a>
          <a href="#footer" className="transition-colors hover:text-foreground">About</a>
        </nav>
        <div className="flex items-center gap-4">
          <Link to="/login" className="hidden text-xs text-muted-foreground hover:text-foreground sm:block">Sign in</Link>
          <Button asChild size="sm"><Link to="/login">Get started <ArrowUpRight className="h-3.5 w-3.5" /></Link></Button>
        </div>
      </header>

      <section id="product" className="grid items-center gap-12 py-16 sm:py-20 lg:grid-cols-2 lg:gap-14 lg:py-24">
        <div>
          <p className="eyebrow"><span className="eyebrow-line" /> ACCESS CONTROL MADE SIMPLE</p>
          <h1 className="max-w-[650px] text-[clamp(42px,5.3vw,68px)] font-semibold leading-[1.04] tracking-[-.065em]">Manage people,<br />roles and permissions.</h1>
          <p className="mt-6 max-w-[490px] text-base leading-7 text-muted-foreground">A modern RBAC platform to control access, secure your applications and scale with ease.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg"><Link to="/login">Get started <ArrowUpRight className="h-4 w-4" /></Link></Button>
            <Button asChild size="lg" variant="outline"><a href="#features">Explore features <ArrowDown className="h-4 w-4" /></a></Button>
          </div>
          <p className="mt-7 flex items-center gap-2 text-xs text-muted-foreground"><span className="grid h-5 w-5 place-items-center rounded-full border text-emerald-600"><Check className="h-3 w-3" /></span>Simple to set up. Clear by design.</p>
        </div>
        <div className="relative pt-4 sm:px-2">
          <p className="mb-4 flex items-center gap-2 pl-2 text-[9px] font-bold tracking-[1.4px] text-muted-foreground"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> YOUR WORKSPACE <span className="text-gray-300">/</span> ACCESS OVERVIEW</p>
          <DashboardPreview />
          <div className="absolute -bottom-5 right-0 flex items-center gap-3 rounded-xl border bg-white px-4 py-3 shadow-subtle sm:-right-3">
            <span className="grid h-7 w-7 place-items-center rounded-full bg-emerald-50 text-emerald-700"><Check className="h-4 w-4" /></span>
            <span><strong className="block text-[10px]">Permissions updated</strong><small className="mt-1 block text-[9px] text-muted-foreground">Changes saved successfully</small></span>
          </div>
        </div>
      </section>

      <section id="security" className="flex flex-wrap items-center justify-center gap-x-7 gap-y-3 border-y py-6 text-center text-[9px] font-bold tracking-[1.4px] text-muted-foreground sm:gap-x-9">
        <span>BUILT FOR CLARITY</span><span className="h-1 w-1 rounded-full bg-gray-300" /><span>SECURE BY DEFAULT</span><span className="h-1 w-1 rounded-full bg-gray-300" /><span>READY TO SCALE</span>
      </section>

      <section id="features" className="py-20 sm:py-24">
        <div className="text-center">
          <p className="eyebrow">LESS COMPLEXITY. MORE CONTROL.</p>
          <h2 className="text-3xl font-semibold tracking-[-.055em] sm:text-[42px]">Everything in its right place.</h2>
          <p className="mt-3 text-sm text-muted-foreground">Useful controls, without the clutter.</p>
        </div>
        <div className="mt-11 grid border-y md:grid-cols-3">
          {features.map(({ number, title, description, icon: Icon }) => (
            <article key={number} className="feature-card group relative min-h-[175px] border-b p-6 md:border-b-0 md:border-r md:last:border-r-0">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold tracking-wider text-indigo-500">{number}</span>
                <Icon className="h-[18px] w-[18px] text-muted-foreground transition-colors group-hover:text-foreground" strokeWidth={1.6} />
              </div>
              <h3 className="mt-7 text-base font-semibold tracking-tight">{title}</h3>
              <p className="mt-2 max-w-[260px] text-[13px] leading-6 text-muted-foreground">{description}</p>
            </article>
          ))}
        </div>
      </section>

      <footer id="footer" className="flex flex-wrap items-center justify-between gap-4 border-t py-7 text-[11px] text-muted-foreground">
        <Brand />
        <span>Thoughtful access control for modern teams.</span>
        <Link to="/login" className="font-semibold text-foreground">Sign in <ArrowUpRight className="ml-1 inline h-3 w-3" /></Link>
      </footer>
    </main>
  );
}