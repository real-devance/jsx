import { Link } from "react-router-dom";

export default function Brand() {
  return (
    <Link to="/" className="inline-flex items-center gap-2.5 text-[17px] font-bold tracking-[-0.7px]" aria-label="Accessly home">
      <span className="brand-mark" aria-hidden="true"><span /></span>
      <span>Accessly</span>
    </Link>
  );
}